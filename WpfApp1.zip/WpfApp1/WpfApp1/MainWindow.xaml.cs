﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        List<Tanulo> adatok = new List<Tanulo>();
        private void btnBetolt_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in File.ReadAllLines("naplo.txt", Encoding.UTF8))
            {
                adatok.Add(new Tanulo(item));
            }
            dgAdatok.ItemsSource = adatok;
        }

        private void btnLetszam_Click(object sender, RoutedEventArgs e)
        {
            int letszam = 0;
            for (int i = 0; i < adatok.Count; i++)
            {
                if (adatok[i].Osztaly == txtJelzes.Text)
                {
                    letszam++;
                }
            }
            lblLetszam.Content = Convert.ToString(letszam);
        }

        private void btnIskolaAtlag_Click(object sender, RoutedEventArgs e)
        {
            int tanulokSzama = adatok.Count;
            double osszeg = 0;
            for (int i = 0; i < adatok.Count; i++)
            {
                osszeg += adatok[i].Atlag;
            }
            double atlag = osszeg / tanulokSzama;

            lblIskolaAtlag.Content = Convert.ToString(atlag);
        }

        private void btnKitunok_Click(object sender, RoutedEventArgs e)
        {
            int darab = 0;
            for (int i = 0; i < adatok.Count; i++)
            {
                if (adatok[i].Atlag == 5)
                {
                    darab++;
                    lbKitunokListaja.Items.Add(adatok[i].Nev);
                }
            }
            lblKitunokSzama.Content = Convert.ToString(darab);
        }

        private void btnFigyelmeztetes_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter sw = new StreamWriter("bukas.txt", append: true) ;
            for (int i = 0; i < adatok.Count; i++)
            {
                if (adatok[i].Atlag <= 2)
                {
                    sw.WriteLine($"{adatok[i].Nev} {adatok[i].Atlag}");
                }
            }
            sw.Close();
        }
    }
    internal class Tanulo
    {
        public string Nev { get; set; }
        public string Osztaly { get; set; }
        public char Nem { get; set; }
        public double Atlag { get; set; }

        public Tanulo(string sor)
        {
            string[] resz = sor.Split(';');
            Nev = resz[0];
            Osztaly = resz[1];
            Nem = Convert.ToChar(resz[2]);
            Atlag = Convert.ToDouble(resz[3]);
        }
    }
}
